from django.shortcuts import render
from random import randint

# Create your views here.

def index(request):
    return render(request, "index.html")

def nav_but():
    return 'index', 'Main Menu'

class PassengerFSM:

    def index(request):
        return render(request, "Passenger/passenger.html")

    def information(request):
        u, u_name = nav_but()
        return render(request, "Passenger/message.html", {'message': "Process Completed", 'u': u, 'u_name':u_name})

    def otp_menu(request):
        return render(request, "Passenger/otp.html", {"title":"OTP Menu"})

    def otp_finish(request):
        price = randint(50, 1000)        
        u, u_name = nav_but()
        return render(request, "Passenger/otp_finish.html", {'price': price, 'u': u, 'u_name':u_name})

    def otp_payment(request, amount):
        u, u_name = nav_but()
        return render(request, "Passenger/otp_payment.html", {'price': amount, 'u': u, 'u_name':u_name})

    def otp_cancel(request):
        u, u_name = nav_but()
        return render(request, "Passenger/message.html", {'message': "Booking Failed", 'u': u, 'u_name':u_name})

    def process_menu(request):
        return render(request, "Passenger/process.html")

    def process_request(request):
        return render(request, "Passenger/process_request.html")

    def process_req_acc(request):
        return render(request, "Passenger/otp.html", {"title":"In Progress"})

    def cancel(request):
        u, u_name = nav_but()
        return render(request, "Passenger/message.html", {'message': "Process Failed", 'u': u, 'u_name':u_name})


class DriverFSM:

    def index(request):
        return render(request, "Driver/driver.html")

    def information(request):
        u, u_name = nav_but()
        return render(request, "Passenger/message.html", {'message': "Process Completed", 'u': u, 'u_name':u_name})

    def cancel(request):
        u, u_name = nav_but()
        return render(request, "Passenger/message.html", {'message': "Process Failed", 'u': u, 'u_name':u_name})

    def accept(request):
        return render(request, "Driver/accept.html")

    def arrive(request):
        return render(request, "Driver/arrive.html")

    def arrive_start(request):
        return render(request, "Driver/start.html")

    def payment(request):
        price = randint(50, 1000)        
        u, u_name = nav_but()
        return render(request, "Driver/payment.html", {'price': price, 'u': u, 'u_name':u_name})
