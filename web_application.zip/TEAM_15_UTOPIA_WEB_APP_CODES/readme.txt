#create virtual environment
python -m venv venv

#activate the environment
.\venv\bin/activate

#install django
pip install django

#run the server
python manage.py runserver

