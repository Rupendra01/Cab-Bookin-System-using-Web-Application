"""BookingSystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from BaseApp.views import index
from BaseApp.views import PassengerFSM as pfsm
from BaseApp.views import DriverFSM as dfsm


urlpatterns = [

    path('admin/', admin.site.urls),
    path('', index, name="index"),
    path('passenger-fsm/', pfsm.index, name="passenger"),
    path('passenger-fsm/information', pfsm.information, name="passenger-information"),
    path('passenger-fsm/otp', pfsm.otp_menu, name="passenger-otp"),
    path('passenger-fsm/otp/finish', pfsm.otp_finish, name="passenger-otp-finish"),
    path('passenger-fsm/otp/cancel', pfsm.otp_cancel, name="passenger-otp-cancel"),
    path('passenger-fsm/otp/finish/payment/<int:amount>', pfsm.otp_payment, name="passenger-otp-payment"),

    path('passenger-fsm/process', pfsm.process_menu, name="passenger-process"),
    path('passenger-fsm/process/request', pfsm.process_request, name="passenger-process-request"),
    path('passenger-fsm/process/request/accept', pfsm.process_req_acc, name="passenger-process-req-acc"),
    path('passenger/cancel', pfsm.cancel, name="passenger-cancel"),

    path('driver-fsm/', dfsm.index, name="driver"),
    path('driver-fsm/information', dfsm.information, name="driver-information"),
    path('driver-fsm/cancel', dfsm.cancel, name="driver-cancel"),
    path('driver-fsm/accept', dfsm.accept, name="driver-accept"),
    path('driver-fsm/accept/arrive', dfsm.arrive, name="driver-accept-arrive"),
    path('driver-fsm/accept/arrive/start', dfsm.arrive_start, name="driver-accept-arrive-start"),
    path('driver-fsm/accept/arrive/start/payment', dfsm.payment, name="driver-accept-arrive-start-payment"),

]
